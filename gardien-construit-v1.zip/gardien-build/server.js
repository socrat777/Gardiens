const http = require('http');
const fs = require('fs');
const path = require('path');
const PORT = process.env.PORT || 10000;
const ROOT = __dirname;
const publicDir = path.join(ROOT, 'public');
const json = (res, code, data) => { res.writeHead(code, {'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'}); res.end(JSON.stringify(data)); };
const sendFile = (res, file, type) => { fs.readFile(file,(e,b)=>{ if(e){res.writeHead(404);res.end('Not found');return;} res.writeHead(200,{'Content-Type':type});res.end(b); }); };
async function worldBank(indicator,country='WLD'){ const u=`https://api.worldbank.org/v2/country/${country}/indicator/${indicator}?format=json&per_page=5`; const r=await fetch(u,{headers:{'User-Agent':'GARDIEN/1.0'}}); if(!r.ok) throw Error('World Bank HTTP '+r.status); const d=await r.json(); const row=(d[1]||[]).find(x=>x.value!==null); return row?{value:row.value,year:row.date}:null; }
async function routes(req,res){
 const u=new URL(req.url,`http://${req.headers.host}`);
 if(u.pathname==='/api/health') return json(res,200,{status:'ok',service:'GARDIEN',time:new Date().toISOString(),mode:'public-demo'});
 if(u.pathname==='/api/evaluate' && req.method==='POST') { let body=''; req.on('data',c=>body+=c); req.on('end',()=>{let x={};try{x=JSON.parse(body||'{}')}catch{}; return json(res,200,{decision:'PROPOSER',principles:['protéger la vie','ne pas nuire intentionnellement','garder l’humain aux commandes','protéger la Terre'],recommendation:`Analyser et simuler avant toute action: ${String(x.question||'situation reçue').slice(0,500)}`,humanDecisionRequired:true});}); return; }
 if(u.pathname==='/api/real-data') { try { const specs=[['life_expectancy','SP.DYN.LE00.IN','Espérance de vie','années'],['co2','EN.ATM.CO2E.PC','CO₂ par personne','tonnes/personne'],['forest','AG.LND.FRST.ZS','Surface forestière','% des terres'],['water','SH.H2O.BASW.ZS','Accès à l’eau potable de base','% de la population']]; const out={}; for(const [k,id,label,unit] of specs){out[k]={label,unit,source:'World Bank',...(await worldBank(id))};} return json(res,200,{ok:true,indicators:out}); } catch(e){ return json(res,503,{ok:false,error:'Données publiques temporairement indisponibles',detail:e.message}); } }
 if(u.pathname==='/api/ask' && req.method==='POST') { let body=''; req.on('data',c=>body+=c); req.on('end',()=>{let x={};try{x=JSON.parse(body||'{}')}catch{}; const q=String(x.question||''); return json(res,200,{answer:'GARDIEN recommande de distinguer les faits, les incertitudes et les hypothèses, puis de comparer plusieurs options sans donner à l’IA le pouvoir de décider seule. Question reçue: '+q.slice(0,500),disclaimer:'Outil d’aide à la réflexion — décision humaine obligatoire.'});}); return; }
 if(req.method==='GET'){ const file=u.pathname==='/'?path.join(publicDir,'index.html'):path.join(publicDir,u.pathname.replace(/^\//,'')); const ext=path.extname(file); const types={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'text/javascript; charset=utf-8','.json':'application/json'}; return sendFile(res,file,types[ext]||'text/plain'); }
 res.writeHead(404);res.end('Not found');
}
http.createServer(routes).listen(PORT,'0.0.0.0',()=>console.log(`GARDIEN listening on ${PORT}`));
