# GARDIEN
Projet web public d’aide à la décision pour protéger l’humanité et la Terre.

## Déploiement Render
- Runtime: Node
- Build: `npm install`
- Start: `npm start`
- Root Directory: vide
- Branch: `main`

## Vérification
- `/api/health`
- `/api/real-data`

Aucune action réelle n’est exécutée par GARDIEN. Les décisions restent humaines.
